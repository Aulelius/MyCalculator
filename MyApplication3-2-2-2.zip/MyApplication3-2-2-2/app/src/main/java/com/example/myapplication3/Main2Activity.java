package com.example.myapplication3;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

// 환산취득가액 어플 메인 화면 자바 코드
public class Main2Activity extends AppCompatActivity {

    // Main2Activity가 최초 실행될 때 실행된다.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Activity의 UI를 R.layout.activity_main2로 지정한다.
        setContentView(R.layout.activity_main2);

        // "환산취득가액 계산기 어플입니다." 메세지를 잠시 보여준다.
        Toast.makeText(getApplicationContext(), "환산취득가액 계산기 어플입니다. ", Toast.LENGTH_LONG).show();

        // 한산취득가액 계산하기가 클릭된 경우의 이벤트  설정
        Button button1 = (Button) findViewById(R.id.mainbutton1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        // 취득당시 기준시가 계산하기가 클릭된 경우의 이벤트 설정
        Button button2 = (Button) findViewById(R.id.mainbutton2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Main3Activity.class);
                startActivity(intent);
            }
        });

        // 취득당시 기준시가 계산하기(구) 클릭된 경우의 이벤트 설정
        Button button3 = (Button) findViewById(R.id.mainbutton3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Main4Activity.class);
                startActivity(intent);
            }
        });

        // 공시지가 조회가 클릭된 경우의 이벤트 설정
        Button button4 = (Button) findViewById(R.id.mainbutton4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Main6Activity.class);
                startActivity(intent);
            }
        });

        // 로딩화면 이벤트 설정
        Intent intent = new Intent(this, LodingActivity.class);
        startActivity(intent);

        // 종료 버튼 이벤트 설정
        Button exitbutton = (Button) findViewById(R.id.exitbutton);
        exitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Main2Activity.this);
                builder.setMessage("환산취득가액 계산기를 종료하시겠습니까?");
                builder.setTitle("종료 알림창").setCancelable(false).setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("종료 알림창");
                alert.show();
            }


        });
    }
}
