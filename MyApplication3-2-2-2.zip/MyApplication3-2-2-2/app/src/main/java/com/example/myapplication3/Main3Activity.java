package com.example.myapplication3;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


    // 취득당시 기준시가 (19900830 이후) 계산 자바 코드
public class Main3Activity extends AppCompatActivity {
    //private DecimalFormat decimalFormat = new DecimalFormat("#,###");
    private EditText number4, number5;
    private TextView result2;
    //private String rs4="";
    //private String rs5="";

   /* // number4 소수점 처리
    TextWatcher watchernum4 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if(!TextUtils.isEmpty(charSequence.toString())&& !charSequence.toString().equals(rs4)) {
        rs4 = decimalFormat.format(Double.parseDouble(charSequence.toString().replaceAll(",", "")));
        number4.setText(rs4);
        number4.setSelection(rs4.length());
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };*/

  /*  // number5 소수점 처리
    TextWatcher watchernum5 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if(!TextUtils.isEmpty(charSequence.toString())&& !charSequence.toString().equals(rs5)) {
            rs5 = decimalFormat.format(Double.parseDouble(charSequence.toString().replaceAll(",","")));
            number5.setText(rs5);
            number5.setSelection(rs5.length());
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };*/

    // 취득당시의 기준시가 계산 관련 메서드 처리
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        number4 = (EditText) findViewById(R.id.number4);
      //  number4.addTextChangedListener(watchernum4);
        number5 = (EditText) findViewById(R.id.number5);
      //  number5.addTextChangedListener(watchernum5);
        result2 = (TextView) findViewById(R.id.result2);
        findViewById(R.id.calculateButton2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long n4 = Long.parseLong(number4.getText().toString());
                long n5 = Long.parseLong(number5.getText().toString());
                result2.setText(Long.toString(n4 * n5 ));
            }
        });
    }

}
