package com.example.myapplication3;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;

public class Main6Activity extends Activity {
    EditText edit;
    TextView text;
    String key = "p7ESdOU1KDhw7I9Pr4dgfwIw%2Bcyqet79u6uSqcB771tmFGhaUsLWba%2FrMvKlI%2BP1hmIId8AL7epLPhsia93WMw%3D%3D";
    String data;
    private String ldCode;
    private String stdrYear;
    private String format;
    private String numOfRows;
    private String pageNo;
    private String IdcodeNm;
    private String regstrSeCodeNm;
    private String proposAreaNm1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        edit = (EditText) findViewById(R.id.edit);
        text = (TextView) findViewById(R.id.text);
    }

    // Button을 클릭했을 때 자동으로 호출되는 callback method
    public void mOnClick(View v){

        switch(v.getId()) {
            case R.id.button:

              new Thread(new Runnable() {
                  @Override
                  public void run() {
                      data = getXmlData(); // //아래 메소드를 호출하여 XML data를 파싱해서 String 객체로 얻어오기


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            text.setText(data); // TextView에 문자열 data 출력
                        }
                    });
                  }
              }).start();

              break;

        }
    }
    String getXmlData() {
        StringBuffer buffer = new StringBuffer();
        String str = edit.getText().toString(); // EditText에 작성된 Text 얻어오기
        String location = URLEncoder.encode(str); //한글의 경우 인식이 안되기에 utf-8 방식으로 encoding     //지역 검색 위한 변수

        String queryUrl = "http://apis.data.go.kr/1611000/nsdi/ReferLandPriceService" // 요청 url
                + "idCode=" + location + "&pageNo=1&numOFRows=1000&ServiceKey=" + key;
        try {
            URL url = new URL(queryUrl); // 문자열로 된 요청 url을 URL 객체로 생성.
            InputStream is = url.openStream(); // url위치로 입력스트림 연결

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8")); // //inputstream 으로부터 xml 입력받기

            String tag;
            xpp.next();
            int eventType = xpp.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag = xpp.getName(); // 태그 이름 얻어오기

                        if (tag.equals("fields")) ; // 첫번째 검색 결과
                        else if (tag.equals(ldCode)) {
                            buffer.append("법정동코드 :");
                            xpp.next();
                            buffer.append(xpp.getText()); // IdCode 요소의 Text 읽어와서 문자열버퍼에 추가
                            buffer.append("\n"); //줄바꿈 문자 추가
                        } else if (tag.equals(stdrYear)) {
                            buffer.append("기준년도 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        } else if (tag.equals(format)) {
                            buffer.append("응답결과 형식 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        } else if (tag.equals(numOfRows)) {
                            buffer.append("검색건수 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        } else if (tag.equals(pageNo)) {
                            buffer.append("페이지 번호");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        } else if (tag.equals(IdcodeNm)) {
                        buffer.append("법정동명 :");
                        xpp.next();
                        buffer.append(xpp.getText());
                        buffer.append("\n");
                    } else if (tag.equals(regstrSeCodeNm)) {
                            buffer.append("특수지구분명 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        } else if(tag.equals(proposAreaNm1)) {
                            buffer.append("용도지역명1: ");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        break;

                    case XmlPullParser.TEXT:
                        break;

                    case XmlPullParser.END_TAG:
                        tag = xpp.getName(); // 태그 이름 얻어오기

                        if (tag.equals("fields")) buffer.append("\n"); // 첫번째 검색결과종료.

                        break;
                }

                eventType = xpp.next();
            }
        } catch (Exception e) {

        }

        buffer.append("파싱 끝\n");

        return buffer.toString(); // StringBuffer 문자열 객체 반환

    }
    }