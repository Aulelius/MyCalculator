package com.example.myapplication3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

    // 환산 취득가액 계산 자바 코드
public class MainActivity extends AppCompatActivity {
     private DecimalFormat decimalFormat = new DecimalFormat("#,###");
    private EditText number1, number2, number3;
    private TextView result;
    /*private String rs = "";
    private String rs2 = "";
    private String rs3 = "";
    private String rrs = "";*/
    private Button calculateButton;
    /*//number1 소수점 처리
    TextWatcher watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (!TextUtils.isEmpty(charSequence.toString()) && !charSequence.toString().equals(rs)) {
                rs = decimalFormat.format(Double.parseDouble(charSequence.toString().replaceAll(",", "")));
                number1.setText(rs);
                number1.setSelection(rs.length());
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };*/

    /*// number2 소수점 처리
    TextWatcher watchernum2 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (!TextUtils.isEmpty(charSequence.toString()) && !charSequence.toString().equals(rs2)) {
                rs2 = decimalFormat.format(Double.parseDouble(charSequence.toString().replaceAll(",", "")));
                number2.setText(rs2);
                number2.setSelection(rs2.length());
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };*/
   /* // number3 소수점 처리
    TextWatcher watchernum3 = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (!TextUtils.isEmpty(charSequence.toString()) && !charSequence.toString().equals(rs3)) {
                rs3 = decimalFormat.format(Double.parseDouble(charSequence.toString().replaceAll(",", "")));
                number3.setText(rs3);
                number3.setSelection(rs3.length());
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };*/
   /* // result 소수점 처리
    TextWatcher watcherresult = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if(!TextUtils.isEmpty(charSequence.toString()) && !charSequence.toString().equals(rrs)) {
            rrs = decimalFormat.format(Double.parseDouble(charSequence.toString().replaceAll("","")));
            result.setText(rrs);

        }
        }

        @Override
       public void afterTextChanged(Editable editable) {

        }
    };
*/
    // 환산취득가액 계산 관련 메서드 처리
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number1 = (EditText) findViewById(R.id.number1);
       // number1.addTextChangedListener(watcher);
        number2 = (EditText) findViewById(R.id.number2);
      //  number2.addTextChangedListener(watchernum2);
        number3 = (EditText) findViewById(R.id.number3);
      //  number3.addTextChangedListener(watchernum3);
        result = (TextView) findViewById(R.id.result);
      //  result.addTextChangedListener(watcherresult);
        findViewById(R.id.calculateButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long n1 = Long.parseLong(number1.getText().toString());
                long n2 = Long.parseLong(number2.getText().toString());
                long n3 = Long.parseLong(number3.getText().toString());
                result.setText(Long.toString(n1 * n2 / n3));

            }
        });
    }
}
