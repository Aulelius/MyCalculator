package com.example.myapplication3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
// 취득당시 기준시가 (19900830 이전) 계산 자바 코드
public class Main4Activity extends AppCompatActivity {
    private EditText number6,number7,number8,number9;
    private TextView result3;
    private Button calculateButton3;

    // 환산취득가액 계산 메서드
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        number6 = (EditText) findViewById(R.id.number6);
        number7 = (EditText) findViewById(R.id.number7);
        number8 = (EditText) findViewById(R.id.number8);
        number9 = (EditText) findViewById(R.id.number9);
        calculateButton3 = (Button) findViewById(R.id.calculateButton3);
        result3 = (TextView) findViewById(R.id.result3);

        findViewById(R.id.calculateButton3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              Long n6 = Long.parseLong(number6.getText().toString());
              Long n7 = Long.parseLong(number7.getText().toString());
              Long n8 = Long.parseLong(number8.getText().toString());
              Long n9 = Long.parseLong(number9.getText().toString());
              result3.setText(Long.toString(n6 * n7 / ((n8 + n9) /2)));
            }
        });

    }
}
