package com.example.myapplication3;

import android.os.Bundle;
import android.os.StrictMode;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Main6Activity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main6);

        StrictMode.enableDefaults();

        TextView status1 = (TextView)findViewById(R.id.search_result);  // 파싱된 결과 확인


}


}
